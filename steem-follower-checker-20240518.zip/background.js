// Background script for the Steem Follower Checker extension.
