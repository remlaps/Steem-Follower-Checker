# Steem-Follower-Checker
A browser extension to get total number of followers, median reputation, and follower network strength for a Steem account.
